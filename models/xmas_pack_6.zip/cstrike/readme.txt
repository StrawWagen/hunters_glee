Last update @ Dec 20, 2008: One more skin has been added to all ribbon tags models, this is tributed to the loss of Caylee

Merry Xmas to everyone first. I hope the sets of these models are nice and easy to understand, and i hope this package doesnt come too late for any Xmas maps :P. 
This package include:
giftbox64x64.mdl
giftbox64x64_ribbon_butterfly.mdl
giftbox64x64_ribbon_curly.mdl
giftbox64x64_ribbon_special.mdl
giftbox64x96h.mdl
giftbox64x96h_ribbon_diagonal.mdl
giftbox64x96h_ribbon_tag.mdl
giftbox64x128h.mdl
giftbox64x128h_ribbon_flower.mdl
giftbox64x128h_ribbon_tag.mdl
giftbox64x128w.mdl
giftbox64x128w_ribbon_special.mdl
giftbox64x128w_ribbon_tag.mdl
giftbox96x96.mdl
giftbox96x96_ribbon_special.mdl
giftbox96x96_ribbon_tag.mdl
giftbox128x128.mdl
giftbox128x128_ribbon_butterfly.mdl
giftbox128x128_ribbon_curly.mdl
giftbox128x128_ribbon_special.mdl
giftbox_mini_octo.mdl
giftbox_mini_quad.mdl
giftbox_mini_ribbon_curly.mdl
giftbox_mini_ribbon_speciala.mdl
giftbox_mini_ribbon_specialb.mdl
giftbox_mini_round.mdl
giftbox_nano.mdl
xmas_teddybear.mdl
xmastree.mdl
xmastree_mini.mdl



There first models introduced here are giftboxes:
Basically there are 6 sets, 
64x64; 
64x96h; 
64x128h; 
64x128w; 
96x96 and 
128x128. 
These models are sized as its named, 64x64 meaning that a player has to crouch-jump to get on, 128x128 is the size bigger/taller than players in-game. In other words, these models are pretty much the same size as the ones in de_dust(or dust2)
You will find this package of models in the path:
USER\counter-strike source\cstrike\models\models_kit\xmas

The following describes the 64x64 set:
The base model "giftbox64x64.mdl" has 3 expansion models for decoration(aka ribbon), they are:
"giftbox64x64_ribbon_butterfly.mdl"
"giftbox64x64_ribbon_curly.mdl"
"giftbox64x64_ribbon_special.mdl"

More details:

giftbox64x64.mdl :
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox64x64_ribbon_butterfly.mdl:
Polycount: 166
LOD model: No
Physbox: No
# of skins: 3

giftbox64x64_ribbon_curly.mdl:
Polycount: 778 (LOD @ 45: 374)
LOD model: YES, only 1
Physbox: No
# of skins: 3

giftbox64x64_ribbon_special.mdl:
Polycount: 943 (LOD @ 55: 385)
LOD model: YES, only 1
Physbox: No
# of skins: 2

-------------
The following describes the 64x96h set:
The base model "giftbox64x96h.mdl" has 2 expansion models for decoration, they are:
"giftbox64x96h_ribbon_diagonal.mdl"
"giftbox64x96h_ribbon_tag.mdl"

More details:

giftbox64x96h.mdl:
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox64x96h_ribbon_diagonal.mdl:
Polycount:  16
LOD model: No
Physbox: No
# of skins: 1

giftbox64x96h_ribbon_tag.mdl:
Polycount:  46
LOD model: No
Physbox: No
# of skins: 8

-------------
The following describes the 64x128h set:
The base model "giftbox64x128h.mdl" has 2 expansion models for decoration, they are:
"giftbox64x128h_ribbon_flower.mdl"
"giftbox64x128h_ribbon_tag.mdl"

More details:

giftbox64x128h.mdl:
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox64x128h_ribbon_flower.mdl:
Polycount: 186 (LOD @ 45: 124)
LOD model: YES, only 1
Physbox: No
# of skins: 1

giftbox64x128h_ribbon_tag.mdl:
Polycount:  46
LOD model: No
Physbox: No
# of skins: 8

-------------
The following describes the 64x128w set:
The base model "giftbox64x128w.mdl" has 2 expansion models for decoration, they are:
"giftbox64x128w_ribbon_special.mdl"
"giftbox64x128w_ribbon_tag.mdl"

More details:

giftbox64x128w.mdl:
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox64x128w_ribbon_special.mdl:
Polycount: 1154 (LOD @ : 428)
LOD model: YES, only 1
Physbox: No
# of skins: 2

giftbox64x128w_ribbon_tag.mdl:
Polycount:  46
LOD model: No
Physbox: No
# of skins: 8

-------------
The following describes the 96x96 set:
The base model "giftbox96x96.mdl" has 2 expansion models for decoration, they are:
"giftbox96x96_ribbon_special.mdl"
"giftbox96x96_ribbon_tag.mdl"

More details:

giftbox96x96.mdl:
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox96x96_ribbon_special.mdl:
Polycount: 1306 (LOD @ 70: 652)
LOD model: YES, only 1
Physbox: No
# of skins: 2

giftbox96x96_ribbon_tag.mdl:
Polycount:  46
LOD model: No
Physbox: No
# of skins: 8

-------------
The following describes the 128x128 set:
The base model "giftbox128x128.mdl" has 3 expansion models for decoration, they are:
"giftbox128x128_ribbon_butterfly.mdl"
"giftbox128x128_ribbon_curly.mdl"
"giftbox128x128_ribbon_special.mdl"

More details:

giftbox128x128.mdl:
Polycount: 28
LOD model: No
Physbox: Yes
# of skins: 5

giftbox128x128_ribbon_butterfly.mdl:
Polycount: 294 (LOD @ 85: 148)
LOD model: YES, only 1
Physbox: No
# of skins: 3

giftbox128x128_ribbon_curly.mdl:
Polycount: 420 (LOD @ 80: 224)
LOD model: YES, only 1
Physbox: No
# of skins: 3

giftbox128x128_ribbon_special.mdl:
Polycount: 1415 (LOD @ 100: 488)
LOD model: YES, only 1
Physbox: No
# of skins: 2

-------------
The tag models has 8 skins, its poetry/verse are listed following:

skin0:
At this holiday season we remember and honor those who are no longer with us and cherish those who are

skin1:
To everyone, Merry Xmas and all the best in the New Year

skin2:
Our wish this holiday season... A world to grow in where children will be safe and free. Peace

skin3:
A son makes the holidays extra bright

skin4:
To our Caylee, wish you will be home safe and celebrate the season with us

skin5:
A daughter has a special way of making Xmas marrier

skin6:
To terrorists, Peace on Earth

skin7:
To CTs, sharing with you the glory, the Victory, the Miracle of all time. have a blessed Xmas and New Year

skin8:
In loving memory of Caylee, you were loved by many and will never be forgotten! May you rest in peace.

NOTICE: ALL giftbox models are prop_static. No animation involved. All base models are equipped with proper physics box, which expansion models(in this case, aka ribbon models) do not have. Expansion models have the same origin as the base model, so it is appropriate to align them on the same coordinates. To align them, simply use paste special function in hammer to line up all models onto exact same coordiante.
Each giftbox model is named to its closed measurement, even thought they are not exact 64, 96 and 128 units in hammer.
To increase the variety of looking of these giftboxes, mapper can even make his own brushes to replace the base models of this package. Base models included here are just simple 6 sided boxes.

-----------
Added on Dec 09, 2008
On request, smaller giftboxes were made. There are 7 related models, named:
giftbox_nano.mdl, 
giftbox_mini_round.mdl, giftbox_mini_quad.mdl, giftbox_mini_octo.mdl, 
giftbox_mini_ribbon_speciala.mdl, giftbox_mini_ribbon_specialb.mdl, giftbox_mini_ribbon_curly.mdl

giftbox_nano.mdl is an (and the only) independent/standalone giftbox model. It does not need any expansions.
Its dimension is about 12x12x12 units in hammer.
giftbox_nano.mdl:
Polycount: 128
LOD model: No
Physbox: Yes, 6-sided boxes
# of skins: 4

The following 6 models have the same concept of "base plus expansion" as mentioned earlier

giftbox_mini_ROUND.mdl:
Polycount: 78
LOD model: No
Physbox: Yes
# of skins: 5

giftbox_mini_QUAD.mdl:
Polycount: 12
LOD model: No
Physbox: Yes
# of skins: 5

giftbox_mini_OCTO.mdl:
Polycount: 28
LOD model: No
Physbox: Yes
# of skins: 5

giftbox_mini_ribbon_speciala.mdl:
Polycount: 341 (LOD @ 20: 166)
LOD model: Yes
Physbox: No
# of skins: 3

giftbox_mini_ribbon_specialb.mdl:
Polycount: 358 (LOD @ 20: 250)
LOD model: Yes
Physbox: No
# of skins: 2

giftbox_mini_ribbon_curly.mdl:
Polycount: 220 (LOD @ 20: 108)
LOD model: Yes
Physbox: No
# of skins: 5


=========
Added on Dec 07, 2008
The second model is a decorated Xmas tree, xmastree.mdl. It has 4 skins and 2 animation sequences. The following list the details:

Dimension(WxLxH): 472 x 432 x 538 units in hammer
Animation sequences names:
windy1
windy2

Polycount: 9038 (LOD @ 90: 5532; LOD @ 180: 3487)
LOD model: 2
Physbox: Yes, simple, only main trunk
# of skins: 4
# of animation sequences: 2

NOTICE: Animated models cannot be assigned as prop_static. For getting this Xmas tree to work, you will have to set prop type to dynamic and hop over to "Default Animation" and input ONE animation sequences name as shown above. If you have better ideas of how to setup these models(or its sequences), please inform me or post a reply below. thank you.

-------------------
Added on Dec 09, 2008
On request, a smaller xmas tree has been added, named 'xmastree_mini.mdl'. This model is a prop_static.
Dimension(WxLxH): 102 x 110 x 128 units in hammer

Polycount: 7107 (LOD @ 30: 4450; LOD @ 50: 3288)
LOD model: 2
Physbox: Yes, simple, only main trunk
# of skins: 4

NOTICE: This mini xmas tree is a static model, different from the regular xmas tree which is animated.


==========
Added on Dec 07, 2008
The third model is a teddy bear, xmas_teddybear.mdl:

Polycount: 371 (LOD @ 50: 191)
LOD model: 1
Physbox: Yes, simple
# of skins: 2

NOTICE: This model is a prop_static with physbox

========

All information listed above is mostly very accurate, however, if you think they are wrong you can easily find out the right information in HLMV. In the Source SDK window , fire up Model Viewer(aka HLMV) and load the mdl file. It will show the most accurate information that you need to make the model works.

Images shown here have been resized to fit the limited resolution, therefore they may not be maintained in the correct asapect ratio.

NOV 28, 2008
-------------------------
Software used: PS CS3, Lightwave 9.5

Installation Instructions:
Straight forward, simply extract the rar/zip file into cstrike folder, so that the paths:
x:\Program Files\Steam\steamapps\USER\counter-strike source\cstrike\models\models_kit
x:\Program Files\Steam\steamapps\USER\counter-strike source\cstrike\materials\models\models_kit
are both containing the files and valid directories

Please respect the right that i made these models. You are allowed to change the texture image, but my name "Mr. Kit" MUST be credited, either tagged onto texture image, written into a readme file or written as the map's credit. You are also welcome to distribute these models, also feel free to use them on your custom map. You are suposed to give me, Mr. Kit, credit while publlishing your map. Please contact me when you release your map to public, so that i can see how good/bad the models react ingame.

To see more of my models pack, please click on my name "mrkit4423" and click submission.

Please dont hesitate to email(or pm) me if you have any problems or spot any flaws.
My email address are kwbingo@yahoo.com.hk or kwbingojp@yahoo.co.jp


